//Pipeline状态
function flagFormatter(value, row, index) {
	var result = "-";
	var toBeSigned = "待签";
	var toBeChecked = "待核";
	var toCharge = "待扣";
	var effected = "生效";
	var surrender = "退保";
	if((!row.lccont||!row.lccont.appflag||row.lccont.appflag==""
		||row.lccont.appflag==null||row.lccont.appflag=="01")){
		result = toBeSigned; //待签
	}else if(row.lccont.appflag == "02"){
		var chargecode = row.lccont.chargecode;
		switch(chargecode){
			case "W":
				result = toCharge;
				break;
			case "S":
				result = effected;
				break;
			case "F":
				result = toCharge;
				break;
			case "E":
				result = toCharge;
				break;
			default:
				break;
		}
	}else if(row.lccont.appflag == "05"){
		result = surrender;
	}else if(row.lccont.appflag == "04"){
		result = effected;
	}else if(row.lccont.appflag == "07"){
		result = surrender;
	}else if(row.lccont.appflag == "06"){
		result = surrender;
	}else if(row.lccont.appflag == "09"){
		result = toBeChecked;
	}else if(row.lccont.appflag == "13"){
		result = toBeChecked;
	}else if(row.lccont.appflag == "10"){
		result = toBeSigned; //待签
	}else if(row.lccont.appflag == "14"){
		var chargecode = row.lccont.chargecode;
		switch(chargecode){
			case "W":
				result = toCharge;
				break;
			case "S":
				result = effected;
				break;
			case "F":
				result = toCharge;
				break;
			case "E":
				result = toCharge;
				break;
			default:
				break;
		}
	}else if(row.lccont.appflag == "12"){
		var chargecode = row.lccont.chargecode;
		switch(chargecode){
			case "W":
				result = toCharge;
				break;
			case "S":
				result = effected;
				break;
			case "F":
				result = toCharge;
				break;
			case "E":
				result = toCharge;
				break;
			default:
				break;
		}
	}
	
    return  result;
}

//缴费年限转换
function formatPayendyear(value, row, index){
	var str = "-";
	
	if("0Y" == value){
		str = "趸交";
	}
	
	if(value != null && value.length >= 2 && value != "0Y"){
		var endFlag = value.substr(value.length-1);
		var startNum = value.substr(0, value.length-1);
		switch(endFlag){
			case "A":
				str = "至"+ startNum +"岁";
				break;
			case "Y":
				str = startNum + "年";
				break;
			default:
				break;
		}
	}
	
	
	return str;
}

//处理回执日期
function formatReceipt(value, row, index){
	var status = flagFormatter(value, row, index);
	var res = value;
	if(status == "生效"){
		if(row.lccont != null && row.lccont.polreceiptdate != null && row.lccont.polreceiptdate != ""){
			var date = row.lccont.polreceiptdate;
			res = date.substr(0,4) + "-" + date.substr(4,2) + "-" + date.substr(6);
		}
	}
	return res;
}


//千分金额
function formatNumber(value, row, index){
	var result = value;
	var reg=/\d{1,3}(?=(\d{3})+$)/g;
	if(value != null && value != ''){
		var valueRes = value.toString();
		var x = valueRes.indexOf(".");
		if( x != -1 ){
			var strArr = valueRes.split("."); //分割带小数点的字符串
//			console.log(strArr);
			result = strArr[0].replace(reg, '$&,') +"."+ strArr[1]; 
		}else{
			result = valueRes.replace(reg, '$&,');
		}
	}
  return result;
}

//日期起止比较
function compareDate(start,end){
	return ((new Date(start.replace(/-/g,"\/"))) <= (new Date(end.replace(/-/g,"\/"))));
}

/***
 * @author CDK
 * true:  now >= date1
 * @param date1
 * @param date2
 * @returns {Boolean}
 */
function compareDateNow(date1 ){
    var oDate1 = new Date(date1);
    var oDate2 = new Date();
    return    oDate2.getTime() >oDate1.getTime();
}

//计算天数
function calculateDays(value, row, index){
   var timeDiff = new Date().getTime() - new Date(value.replace(/-/g,"\/")).getTime();
   return Math.floor(timeDiff/(24*3600*1000));
}


//成功率format
function formatSuccessRate(value, row, index){
	var res = "-";
    if(value != null && value != ""){
	    res = value + "%";
    }
    return res;
}