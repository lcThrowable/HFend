update elementsofcontrol set cssclass='textarea_remark' where sid='PIPLINEINFO' and combinedid='ROLE:RM' and ID='remark'
commit;